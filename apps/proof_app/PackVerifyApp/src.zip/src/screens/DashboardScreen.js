
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, FlatList, StyleSheet, SafeAreaView, Platform, StatusBar } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SIZES } from '../constants/theme';
import { MOCK_ORDERS } from '../constants/mockData';
import OrderCard from '../components/OrderCard';

const DashboardScreen = ({ navigation, route }) => {
  const [searchQuery, setSearchQuery] = useState('');
  // 1. Convert Mock Data to State so we can update it
  const [orders, setOrders] = useState(MOCK_ORDERS);
  
  const user = route.params?.user || { name: 'Unknown', id: '000' };

  // 2. Listen for "Completed" signal from Camera Screen
  useEffect(() => {
    if (route.params?.completedOrderId) {
        const completedId = route.params.completedOrderId;
        
        // Update the order status to 'Completed'
        const updatedOrders = orders.map(order => 
            order.id === completedId 
            ? { ...order, status: 'Completed', isUrgent: false } 
            : order
        );
        
        setOrders(updatedOrders);
    }
  }, [route.params?.completedOrderId]);

  const filteredOrders = orders.filter(order => 
    order.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const renderHeader = () => (
    <View style={styles.headerContainer}>
      <LinearGradient
        colors={[COLORS.primary, COLORS.primaryLight]}
        style={styles.headerGradient}
      >
        <SafeAreaView>
          <View style={styles.headerContent}>
            <View style={styles.userRow}>
              <View style={styles.avatar}>
                <Text style={styles.avatarText}>{user.name.charAt(0)}</Text>
              </View>
              <View>
                <Text style={styles.welcomeText}>Welcome back,</Text>
                <Text style={styles.userName}>{user.name}</Text>
              </View>
            </View>
            <View style={styles.rolePill}>
              <Text style={styles.roleText}>{user.role}</Text>
            </View>
          </View>

          <View style={styles.searchWrapper}>
            <View style={styles.searchContainer}>
              <Ionicons name="search" size={20} color={COLORS.textLight} />
              <TextInput 
                style={styles.searchInput}
                placeholder="Search Order ID..."
                placeholderTextColor={COLORS.textLight}
                value={searchQuery}
                onChangeText={setSearchQuery}
              />
            </View>
            <View style={styles.scanButton}>
                <Ionicons name="qr-code" size={24} color={COLORS.white} />
            </View>
          </View>
        </SafeAreaView>
      </LinearGradient>
    </View>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.primary} />
      <View style={styles.content}>
        {renderHeader()}
        
        <View style={styles.listContainer}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Assigned Orders</Text>
            <Text style={styles.countBadge}>{filteredOrders.length}</Text>
          </View>

          <FlatList
            data={filteredOrders}
            keyExtractor={item => item.id}
            renderItem={({ item }) => (
              <OrderCard 
                order={item} 
                onPress={() => navigation.navigate('OrderDetails', { orderId: item.id, user: user })}
              />
            )}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  content: { flex: 1 },
  headerContainer: { marginBottom: 10, backgroundColor: COLORS.background },
  headerGradient: { paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight + 10 : 20, paddingBottom: 25, paddingHorizontal: SIZES.padding, borderBottomLeftRadius: 30, borderBottomRightRadius: 30 },
  headerContent: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  userRow: { flexDirection: 'row', alignItems: 'center' },
  avatar: { width: 45, height: 45, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center', marginRight: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.3)' },
  avatarText: { color: COLORS.white, fontSize: 20, fontWeight: 'bold' },
  welcomeText: { fontSize: 12, color: '#cbd5e1' },
  userName: { fontSize: 18, fontWeight: 'bold', color: COLORS.white },
  rolePill: { backgroundColor: 'rgba(16, 185, 129, 0.2)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8, borderWidth: 1, borderColor: COLORS.secondary },
  roleText: { color: '#6ee7b7', fontSize: 12, fontWeight: 'bold' },
  searchWrapper: { flexDirection: 'row', alignItems: 'center' },
  searchContainer: { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.white, height: 50, borderRadius: 14, paddingHorizontal: 15, marginRight: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.1, shadowRadius: 10, elevation: 5 },
  searchInput: { flex: 1, marginLeft: 10, fontSize: 16, color: COLORS.textDark },
  scanButton: { width: 50, height: 50, borderRadius: 14, backgroundColor: COLORS.secondary, justifyContent: 'center', alignItems: 'center', shadowColor: COLORS.secondary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 5 },
  listContainer: { flex: 1, paddingHorizontal: SIZES.padding },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 15, marginTop: 10 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', color: COLORS.textDark, marginRight: 8 },
  countBadge: { backgroundColor: '#e2e8f0', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 12, fontSize: 12, fontWeight: 'bold', color: COLORS.textLight },
  listContent: { paddingBottom: 20 }
});

export default DashboardScreen;