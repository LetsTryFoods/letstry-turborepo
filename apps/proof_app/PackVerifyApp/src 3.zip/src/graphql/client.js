import { ApolloClient, InMemoryCache, createHttpLink } from '@apollo/client';
import { setContext } from '@apollo/client/link/context';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = 'https://apiv3.letstryfoods.com/graphql';

const httpLink = createHttpLink({
  uri: API_URL,
});

const authLink = setContext(async (_, { headers }) => {
  const token = await AsyncStorage.getItem('userToken');

  console.log('🔐 [CLIENT] Sending token?', !!token);

  return {
    headers: {
      ...headers,
      Authorization: token ? `Bearer ${token}` : '', // 🔥 CAPITAL A FIX
    },
  };
});

const client = new ApolloClient({
  link: authLink.concat(httpLink),
  cache: new InMemoryCache(),
});

export default client;
