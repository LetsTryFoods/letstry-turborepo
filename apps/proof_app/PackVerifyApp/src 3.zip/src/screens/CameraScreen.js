

// import { Ionicons } from '@expo/vector-icons';
// import { CameraView, useCameraPermissions } from 'expo-camera';
// import { LinearGradient } from 'expo-linear-gradient';
// import * as MediaLibrary from 'expo-media-library';
// import { useEffect, useRef, useState } from 'react';
// import {
//   Alert,
//   Image,
//   StatusBar,
//   Text,
//   TouchableOpacity,
//   View,
// } from 'react-native';
// import ViewShot from 'react-native-view-shot';
// import { COLORS } from '../constants/theme';

// const PHOTO_STEPS = [
//   { id: 'inner1', label: 'STEP 1 / 3', desc: 'Capture items inside the box' },
//   { id: 'inner2', label: 'STEP 2 / 3', desc: 'Capture protective packaging' },
//   { id: 'outer', label: 'STEP 3 / 3', desc: 'Capture sealed box with label' },
// ];

// const CameraScreen = ({ navigation, route }) => {
//   const { order, user } = route.params;

//   const cameraRef = useRef(null);
//   const viewShotRef = useRef(null);

//   const [permission, requestPermission] = useCameraPermissions();
//   const [mediaPermission, requestMediaPermission] =
//     MediaLibrary.usePermissions();

//   /** 📦 PACKING STATE */
//   const [items, setItems] = useState(
//     order.items.map(i => ({
//       ...i,
//       scannedQty: 0,
//     }))
//   );

//   const [scanLocked, setScanLocked] = useState(false);
//   const [packingDone, setPackingDone] = useState(false);

//   /** 📸 PHOTO STATE */
//   const [currentStepIndex, setCurrentStepIndex] = useState(0);
//   const [currentPhoto, setCurrentPhoto] = useState(null);
//   const [isProcessing, setIsProcessing] = useState(false);

//   const currentStep = PHOTO_STEPS[currentStepIndex];

//   useEffect(() => {
//     if (!permission?.granted) requestPermission();
//     if (!mediaPermission?.granted) requestMediaPermission();
//   }, []);

//   /** ======================
//    * 📦 EAN SCAN HANDLER
//    ======================= */
//   const handleBarcodeScan = ({ data }) => {
//     if (scanLocked) return;
//     setScanLocked(true);

//     const index = items.findIndex(i => i.ean === data);

//     if (index === -1) {
//       Alert.alert('❌ Invalid Item', 'EAN not part of this order');
//       setScanLocked(false);
//       return;
//     }

//     setItems(prev =>
//       prev.map((item, i) => {
//         if (i === index) {
//           if (item.scannedQty >= item.quantity) {
//             Alert.alert('ℹ️ Already Packed', item.name);
//             return item;
//           }
//           return { ...item, scannedQty: item.scannedQty + 1 };
//         }
//         return item;
//       })
//     );

//     setTimeout(() => setScanLocked(false), 600);
//   };

//   useEffect(() => {
//     const done = items.every(i => i.scannedQty === i.quantity);
//     if (done) setPackingDone(true);
//   }, [items]);

//   /** ======================
//    * 📸 PHOTO LOGIC
//    ======================= */
//   const takePicture = async () => {
//     const data = await cameraRef.current.takePictureAsync({
//       quality: 0.8,
//       skipProcessing: true,
//     });
//     setCurrentPhoto(data.uri);
//   };

//   const confirmAndNext = async () => {
//     setIsProcessing(true);
//     const uri = await viewShotRef.current.capture();
//     await MediaLibrary.saveToLibraryAsync(uri);

//     if (currentStepIndex < PHOTO_STEPS.length - 1) {
//       setCurrentPhoto(null);
//       setCurrentStepIndex(i => i + 1);
//     } else {
//       Alert.alert('🎉 Success', 'Order Packed Successfully', [
//         {
//           text: 'Back to Dashboard',
//           onPress: () => navigation.navigate('Dashboard'),
//         },
//       ]);
//     }
//     setIsProcessing(false);
//   };

//   if (!permission?.granted) return <View style={{ flex: 1 }} />;

//   /** ======================
//    * 📸 PHOTO PREVIEW
//    ======================= */
//   if (currentPhoto) {
//     return (
//       <View style={styles.container}>
//         <StatusBar hidden />
//         <ViewShot ref={viewShotRef} style={{ flex: 1 }}>
//           <Image source={{ uri: currentPhoto }} style={{ flex: 1 }} />
//           <LinearGradient
//             colors={['transparent', 'rgba(0,0,0,0.9)']}
//             style={styles.watermarkGradient}
//           >
//             <Text style={styles.wmTitle}>PACKED BY {user.name}</Text>
//             <Text style={styles.wmSub}>ORDER {order.orderNumber}</Text>
//           </LinearGradient>
//         </ViewShot>

//         <View style={styles.actionOverlay}>
//           <TouchableOpacity
//             onPress={() => setCurrentPhoto(null)}
//             style={styles.btnBlur}
//           >
//             <Ionicons name="refresh" size={24} color="#fff" />
//           </TouchableOpacity>

//           <TouchableOpacity
//             onPress={confirmAndNext}
//             style={styles.btnPrimary}
//           >
//             <Text style={styles.btnText}>
//               {isProcessing ? 'SAVING...' : 'CONFIRM & NEXT'}
//             </Text>
//           </TouchableOpacity>
//         </View>
//       </View>
//     );
//   }

//   /** ======================
//    * 📦 SCAN MODE
//    ======================= */
//   if (!packingDone) {
//     return (
//       <View style={{ flex: 1, backgroundColor: '#000' }}>
//         <StatusBar hidden />
//         <CameraView
//           style={{ flex: 1 }}
//           ref={cameraRef}
//           barcodeScannerSettings={{
//             barcodeTypes: ['ean13'],
//           }}
//           onBarcodeScanned={handleBarcodeScan}
//         />

//         <View style={styles.scanOverlay}>
//           <Text style={styles.scanTitle}>Scan Items</Text>
//           {items.map(i => (
//             <Text
//               key={i.productId}
//               style={{
//                 color:
//                   i.scannedQty === i.quantity
//                     ? COLORS.success
//                     : '#fff',
//               }}
//             >
//               {i.name} — {i.scannedQty}/{i.quantity}
//             </Text>
//           ))}
//         </View>
//       </View>
//     );
//   }

//   /** ======================
//    * 📸 PHOTO MODE
//    ======================= */
//   return (
//     <View style={styles.container}>
//       <StatusBar hidden />
//       <CameraView style={{ flex: 1 }} ref={cameraRef}>
//         <LinearGradient
//           colors={['rgba(0,0,0,0.8)', 'transparent']}
//           style={styles.topHud}
//         >
//           <Text style={styles.stepLabel}>{currentStep.label}</Text>
//           <Text style={styles.stepDesc}>{currentStep.desc}</Text>
//         </LinearGradient>

//         <View style={styles.bottomControls}>
//           <TouchableOpacity
//             onPress={() => navigation.goBack()}
//             style={styles.iconBtn}
//           >
//             <Ionicons name="close" size={28} color="#fff" />
//           </TouchableOpacity>

//           <TouchableOpacity
//             onPress={takePicture}
//             style={styles.shutterBtn}
//           >
//             <View style={styles.shutterInner} />
//           </TouchableOpacity>

//           <View style={{ width: 50 }} />
//         </View>
//       </CameraView>
//     </View>
//   );
// };

// const styles = {
//   container: { flex: 1, backgroundColor: '#000' },
//   watermarkGradient: {
//     position: 'absolute',
//     bottom: 0,
//     left: 0,
//     right: 0,
//     padding: 20,
//   },
//   wmTitle: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
//   wmSub: { color: '#ccc', fontSize: 12 },
//   actionOverlay: {
//     position: 'absolute',
//     bottom: 40,
//     left: 20,
//     right: 20,
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//   },
//   btnBlur: {
//     width: 50,
//     height: 50,
//     borderRadius: 25,
//     backgroundColor: 'rgba(255,255,255,0.2)',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   btnPrimary: {
//     flex: 1,
//     marginLeft: 16,
//     backgroundColor: COLORS.primary,
//     borderRadius: 30,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   btnText: { color: '#fff', fontWeight: 'bold' },
//   scanOverlay: {
//     position: 'absolute',
//     bottom: 40,
//     left: 20,
//     right: 20,
//     backgroundColor: 'rgba(0,0,0,0.6)',
//     padding: 16,
//     borderRadius: 12,
//   },
//   scanTitle: { color: '#fff', fontWeight: 'bold', marginBottom: 8 },
//   topHud: { paddingTop: 50, paddingBottom: 20, alignItems: 'center' },
//   stepLabel: { color: COLORS.secondary, fontWeight: 'bold' },
//   stepDesc: { color: '#fff' },
//   bottomControls: {
//     position: 'absolute',
//     bottom: 40,
//     width: '100%',
//     flexDirection: 'row',
//     justifyContent: 'space-around',
//   },
//   shutterBtn: {
//     width: 80,
//     height: 80,
//     borderRadius: 40,
//     borderWidth: 4,
//     borderColor: '#fff',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   shutterInner: {
//     width: 60,
//     height: 60,
//     borderRadius: 30,
//     backgroundColor: '#fff',
//   },
//   iconBtn: {
//     padding: 14,
//     backgroundColor: 'rgba(255,255,255,0.2)',
//     borderRadius: 30,
//   },
// };

// export default CameraScreen;













import { Ionicons } from '@expo/vector-icons';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as FileSystem from 'expo-file-system'; // Required for Base64 conversion
import { LinearGradient } from 'expo-linear-gradient';
import * as MediaLibrary from 'expo-media-library';
import { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  Vibration,
  View
} from 'react-native';
import ViewShot from 'react-native-view-shot';
import { COLORS } from '../constants/theme';

// ✅ BACKEND IMPORTS
import { useMutation } from '@apollo/client';
import { COMPLETE_PACKING, SCAN_ITEM, UPLOAD_EVIDENCE } from '../graphql/queries';

// Steps mapped to "Pre-pack" vs "Post-pack" logic
const PHOTO_STEPS = [
  { id: 'inner', group: 'PRE', label: 'STEP 1 / 3', desc: 'Capture items inside box' },
  { id: 'protective', group: 'PRE', label: 'STEP 2 / 3', desc: 'Capture protective packaging' },
  { id: 'label', group: 'POST', label: 'STEP 3 / 3', desc: 'Capture sealed box & label' },
];

const CameraScreen = ({ navigation, route }) => {
  const { order, user } = route.params;

  const cameraRef = useRef(null);
  const viewShotRef = useRef(null);
  const [permission, requestPermission] = useCameraPermissions();
  const [mediaPermission, requestMediaPermission] = MediaLibrary.usePermissions();

  /** 📦 PACKING STATE */
  const [items, setItems] = useState(order.items.map(i => ({ ...i, scannedQty: 0 })));
  const [scanLocked, setScanLocked] = useState(false);
  const [packingDone, setPackingDone] = useState(false);

  /** 📸 PHOTO STATE */
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [currentPhoto, setCurrentPhoto] = useState(null);
  const [evidencePaths, setEvidencePaths] = useState({ pre: [], post: [] });
  const [isProcessing, setIsProcessing] = useState(false);

  const currentStep = PHOTO_STEPS[currentStepIndex];

  // ✅ 1. SCAN ITEM MUTATION
  const [scanItemMutation] = useMutation(SCAN_ITEM);

  // ✅ 2. UPLOAD EVIDENCE MUTATION
  const [uploadEvidenceMutation] = useMutation(UPLOAD_EVIDENCE);

  // ✅ 3. COMPLETE MUTATION
  const [completePackingMutation] = useMutation(COMPLETE_PACKING);

  useEffect(() => {
    if (!permission?.granted) requestPermission();
    if (!mediaPermission?.granted) requestMediaPermission();
  }, []);

  /** ======================
   * 📦 PHASE 1: SERVER-SIDE SCANNING
   ======================= */
  const handleBarcodeScan = async ({ data }) => {
    if (scanLocked) return;
    setScanLocked(true);

    try {
      // 1. Call Server to Validate
      const { data: result } = await scanItemMutation({
        variables: {
          input: {
            packingOrderId: order.id,
            ean: data
          }
        }
      });

      const log = result.scanItem;

      if (!log.isValid) {
        Vibration.vibrate();
        Alert.alert('❌ Invalid Item', `Server says: ${log.errorType || 'Unknown Error'}`);
      } else {
        // 2. Update Local State on Success
        setItems(prev => {
          const newItems = [...prev];
          const index = newItems.findIndex(i => i.productId === log.matchedProductId);
          if (index !== -1) {
             // Only increment if not full (server handles logic too, but good for UI)
             if(newItems[index].scannedQty < newItems[index].quantity) {
                 newItems[index].scannedQty = log.scannedQuantity;
             }
          }
          return newItems;
        });
      }
    } catch (err) {
      Vibration.vibrate();
      Alert.alert("Network Error", "Scan failed: " + err.message);
    } finally {
      setTimeout(() => setScanLocked(false), 1000);
    }
  };

  // Check Completion
  useEffect(() => {
    const allScanned = items.every(i => i.scannedQty >= i.quantity);
    if (allScanned && !packingDone) {
        setPackingDone(true);
        Alert.alert("✅ Scanning Complete", "Proceeding to evidence photos.");
    }
  }, [items]);

  /** ======================
   * 📸 PHASE 2: PHOTO CAPTURE
   ======================= */
  const takePicture = async () => {
    if (!cameraRef.current) return;
    const data = await cameraRef.current.takePictureAsync({ quality: 0.6, skipProcessing: true });
    setCurrentPhoto(data.uri);
  };

  /** ======================
   * 📤 PHASE 3: UPLOAD & FINISH
   ======================= */
  const confirmAndNext = async () => {
    setIsProcessing(true);
    try {
        // 1. Capture ViewShot (Watermark)
        const uri = await viewShotRef.current.capture();
        
        // 2. Store URI based on Group (Pre vs Post)
        const newPaths = { ...evidencePaths };
        if (currentStep.group === 'PRE') newPaths.pre.push(uri);
        else newPaths.post.push(uri);
        setEvidencePaths(newPaths);

        // 3. Move Next or Finish
        if (currentStepIndex < PHOTO_STEPS.length - 1) {
            setCurrentPhoto(null);
            setCurrentStepIndex(i => i + 1);
            setIsProcessing(false);
        } else {
            // ✅ LAST STEP: UPLOAD ALL & COMPLETE
            await finalSubmission(newPaths);
        }
    } catch (e) {
        Alert.alert("Error", "Failed to process photo.");
        setIsProcessing(false);
    }
  };

  const finalSubmission = async (paths) => {
      try {
        // 1. Convert Images to Base64 Strings (for [String!] schema)
        const preImages = await Promise.all(paths.pre.map(uri => FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 })));
        const postImages = await Promise.all(paths.post.map(uri => FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 })));

        // 2. Upload Evidence
        await uploadEvidenceMutation({
            variables: {
                input: {
                    packingOrderId: order.id,
                    prePackImages: preImages, // Sending Base64 strings
                    postPackImages: postImages,
                    actualBoxCode: null // Optional
                }
            }
        });

        // 3. Complete Packing
        await completePackingMutation({
            variables: { packingOrderId: order.id }
        });

        Alert.alert('🎉 SUCCESS', 'Order packed and uploaded!', [
            { text: 'Back to Dashboard', onPress: () => navigation.navigate('Dashboard') }
        ]);

      } catch (err) {
          Alert.alert("Submission Error", err.message);
      } finally {
          setIsProcessing(false);
      }
  };

  /** ======================
   * 🖼️ PREVIEW UI
   ======================= */
  if (currentPhoto) {
    return (
      <View style={styles.container}>
        <StatusBar hidden />
        <ViewShot ref={viewShotRef} style={{ flex: 1 }} options={{ format: "jpg", quality: 0.8 }}>
          <Image source={{ uri: currentPhoto }} style={{ flex: 1 }} />
          <LinearGradient colors={['transparent', 'rgba(0,0,0,0.8)']} style={styles.watermarkGradient}>
            <Text style={styles.wmTitle}>PACKED BY {user.name.toUpperCase()}</Text>
            <Text style={styles.wmSub}>ORDER #{order.orderNumber} • {new Date().toLocaleTimeString()}</Text>
            <Text style={styles.wmSub}>{currentStep.desc.toUpperCase()}</Text>
          </LinearGradient>
        </ViewShot>

        <View style={styles.actionOverlay}>
          <TouchableOpacity onPress={() => setCurrentPhoto(null)} style={styles.btnBlur}>
            <Ionicons name="refresh" size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity onPress={confirmAndNext} style={styles.btnPrimary} disabled={isProcessing}>
            {isProcessing ? <ActivityIndicator color="#fff" /> : (
                <Text style={styles.btnText}>
                    {currentStepIndex === PHOTO_STEPS.length - 1 ? "FINISH 🚀" : "NEXT STEP"}
                </Text>
            )}
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  /** ======================
   * 📦 SCANNER UI
   ======================= */
  if (!packingDone) {
    return (
      <View style={styles.container}>
        <StatusBar hidden />
        <CameraView
          style={{ flex: 1 }}
          ref={cameraRef}
          barcodeScannerSettings={{ barcodeTypes: ['ean13', 'ean8', 'qr'] }}
          onBarcodeScanned={handleBarcodeScan}
        >
            <View style={styles.scanOverlay}>
                <View style={styles.scanHeader}>
                    <Text style={styles.scanTitle}>SCANNING...</Text>
                    {scanLocked && <ActivityIndicator size="small" color="white" style={{marginLeft: 10}}/>}
                </View>
                
                <View style={styles.scanList}>
                    {items.map((i, index) => {
                        const isComplete = i.scannedQty >= i.quantity;
                        return (
                            <View key={index} style={styles.scanRow}>
                                <View style={{flex: 1}}>
                                    <Text style={[styles.scanItemName, isComplete && styles.textSuccess]}>{i.name}</Text>
                                    <Text style={styles.scanSku}>{i.sku}</Text>
                                </View>
                                <Text style={[styles.scanItemCount, isComplete && styles.textSuccess]}>
                                    {i.scannedQty}/{i.quantity}
                                </Text>
                                {isComplete ? <Ionicons name="checkmark-circle" size={20} color={COLORS.success} /> : <Ionicons name="ellipse-outline" size={20} color="#666" />}
                            </View>
                        );
                    })}
                </View>
            </View>
        </CameraView>
      </View>
    );
  }

  /** ======================
   * 📸 PHOTO UI
   ======================= */
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <CameraView style={{ flex: 1 }} ref={cameraRef}>
        <LinearGradient colors={['rgba(0,0,0,0.8)', 'transparent']} style={styles.topHud}>
          <Text style={styles.stepLabel}>{currentStep.label}</Text>
          <Text style={styles.stepDesc}>{currentStep.desc}</Text>
        </LinearGradient>

        <View style={styles.bottomControls}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.iconBtn}>
            <Ionicons name="close" size={28} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity onPress={takePicture} style={styles.shutterBtn}>
            <View style={styles.shutterInner} />
          </TouchableOpacity>
          <View style={{ width: 50 }} /> 
        </View>
      </CameraView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  watermarkGradient: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 20, paddingTop: 60 },
  wmTitle: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  wmSub: { color: '#ccc', fontSize: 12, marginTop: 2 },
  actionOverlay: { position: 'absolute', bottom: 40, left: 20, right: 20, flexDirection: 'row', justifyContent: 'space-between' },
  btnBlur: { width: 50, height: 50, borderRadius: 25, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  btnPrimary: { flex: 1, marginLeft: 16, backgroundColor: COLORS.primary, borderRadius: 30, alignItems: 'center', justifyContent: 'center' },
  btnText: { color: '#fff', fontWeight: 'bold', fontSize: 14 },
  scanOverlay: { position: 'absolute', top: 50, left: 20, right: 20, backgroundColor: 'rgba(0,0,0,0.85)', borderRadius: 12, padding: 16 },
  scanHeader: { borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.2)', paddingBottom: 10, marginBottom: 10, flexDirection: 'row', alignItems: 'center' },
  scanTitle: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  scanList: { gap: 12 },
  scanRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  scanItemName: { color: '#eee', fontSize: 14, fontWeight: '600' },
  scanSku: { color: '#888', fontSize: 10 },
  scanItemCount: { color: '#fff', fontWeight: 'bold', marginHorizontal: 8 },
  textSuccess: { color: COLORS.success },
  topHud: { paddingTop: 60, paddingBottom: 20, alignItems: 'center' },
  stepLabel: { color: COLORS.secondary || '#fbbf24', fontWeight: 'bold', fontSize: 14, letterSpacing: 1 },
  stepDesc: { color: '#fff', fontSize: 18, fontWeight: '600', marginTop: 4 },
  bottomControls: { position: 'absolute', bottom: 50, width: '100%', flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center' },
  shutterBtn: { width: 80, height: 80, borderRadius: 40, borderWidth: 4, borderColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  shutterInner: { width: 64, height: 64, borderRadius: 32, backgroundColor: '#fff' },
  iconBtn: { padding: 12, backgroundColor: 'rgba(0,0,0,0.4)', borderRadius: 30 },
});

export default CameraScreen;