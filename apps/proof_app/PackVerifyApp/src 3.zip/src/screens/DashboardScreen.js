// import { useQuery } from '@apollo/client';
// import {
//   ActivityIndicator,
//   FlatList,
//   Text,
//   TouchableOpacity,
//   View,
// } from 'react-native';
// import { GET_MY_ASSIGNED_ORDERS } from '../graphql/queries';

// const DashboardScreen = ({ navigation }) => {
//   const { data, loading, error, refetch } = useQuery(
//     GET_MY_ASSIGNED_ORDERS,
//     {
//       fetchPolicy: 'network-only',
//       pollInterval: 15000,
//     }
//   );

//   if (loading) {
//     return <ActivityIndicator size="large" />;
//   }

//   if (error) {
//     console.log('Dashboard Error:', error.message);
//     return (
//       <View style={{ padding: 20 }}>
//         <Text>Something went wrong</Text>
//       </View>
//     );
//   }

//   const orders = data?.getMyAssignedOrders ?? [];

//   if (orders.length === 0) {
//     return (
//       <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
//         <Text>No orders assigned</Text>
//         <TouchableOpacity onPress={refetch}>
//           <Text style={{ marginTop: 10, color: 'blue' }}>Refresh</Text>
//         </TouchableOpacity>
//       </View>
//     );
//   }

//   return (
//     <FlatList
//       data={orders}
//       keyExtractor={(item) => item.id}
//       onRefresh={refetch}
//       refreshing={loading}
//       renderItem={({ item }) => (
//         <TouchableOpacity
//           onPress={() =>
//             navigation.navigate('OrderDetails', {
//               packingOrderId: item.id,
//             })
//           }
//         >
//           <View
//             style={{
//               padding: 16,
//               borderBottomWidth: 1,
//               borderColor: '#eee',
//             }}
//           >
//             <Text style={{ fontSize: 16, fontWeight: 'bold' }}>
//               Order #{item.orderNumber}
//             </Text>

//             <Text>Status: {item.status}</Text>
//             <Text>Priority: {item.priority}</Text>

//             {item.isExpress && <Text>🚀 Express</Text>}
//             {item.hasErrors && <Text style={{ color: 'red' }}>⚠ Has Errors</Text>}
//           </View>
//         </TouchableOpacity>
//       )}
//     />
//   );
// };

// export default DashboardScreen;






// import { Ionicons } from '@expo/vector-icons';
// import { LinearGradient } from 'expo-linear-gradient';
// import { useState } from 'react';
// import {
//   ActivityIndicator,
//   FlatList,
//   Platform,
//   SafeAreaView,
//   StatusBar,
//   StyleSheet,
//   Text,
//   TextInput,
//   View,
// } from 'react-native';

// import { useQuery } from '@apollo/client';
// import OrderCard from '../components/OrderCard';
// import { COLORS, SIZES } from '../constants/theme';
// import { GET_MY_ASSIGNED_ORDERS } from '../graphql/queries';

// const DashboardScreen = ({ navigation, route }) => {
//   const [searchQuery, setSearchQuery] = useState('');
//   const user = route?.params?.user ?? { name: 'Packer' };

//   const { data, loading, error, refetch } = useQuery(
//     GET_MY_ASSIGNED_ORDERS,
//     {
//       fetchPolicy: 'network-only',
//       pollInterval: 15000,
//     }
//   );

//   if (error) {
//     console.log('Dashboard Error:', error.message);
//   }

//   const orders = data?.getMyAssignedOrders ?? [];

//   const filteredOrders = orders.filter(o =>
//     (o.orderNumber || o.id)
//       .toLowerCase()
//       .includes(searchQuery.toLowerCase())
//   );

//   return (
//     <View style={styles.container}>
//       <StatusBar barStyle="light-content" backgroundColor={COLORS.primary} />

//       {/* HEADER */}
//       <LinearGradient
//         colors={[COLORS.primary, COLORS.primaryLight]}
//         style={styles.headerGradient}
//       >
//         <SafeAreaView>
//           <View style={styles.headerContent}>
//             <View style={styles.userRow}>
//               <View style={styles.avatar}>
//                 <Text style={styles.avatarText}>
//                   {user.name.charAt(0)}
//                 </Text>
//               </View>
//               <View>
//                 <Text style={styles.welcomeText}>Welcome back</Text>
//                 <Text style={styles.userName}>{user.name}</Text>
//               </View>
//             </View>

//             <View style={styles.rolePill}>
//               <Text style={styles.roleText}>PACKER</Text>
//             </View>
//           </View>

//           <View style={styles.searchWrapper}>
//             <View style={styles.searchContainer}>
//               <Ionicons name="search" size={20} color={COLORS.textLight} />
//               <TextInput
//                 style={styles.searchInput}
//                 placeholder="Search order..."
//                 value={searchQuery}
//                 onChangeText={setSearchQuery}
//               />
//             </View>

//             <View style={styles.scanButton}>
//               <Ionicons
//                 name="refresh"
//                 size={22}
//                 color="#fff"
//                 onPress={refetch}
//               />
//             </View>
//           </View>
//         </SafeAreaView>
//       </LinearGradient>

//       {/* LIST */}
//       <View style={styles.listContainer}>
//         {loading ? (
//           <ActivityIndicator
//             size="large"
//             color={COLORS.primary}
//             style={{ marginTop: 40 }}
//           />
//         ) : (
//           <FlatList
//             data={filteredOrders}
//             keyExtractor={item => item.id}
//             refreshing={loading}
//             onRefresh={refetch}
//             contentContainerStyle={styles.listContent}
//             renderItem={({ item }) => (
//               <OrderCard
//                 order={{
//                   id: item.orderNumber,
//                   status: item.status,
//                   priority: item.priority,
//                   itemsCount: item.items?.length ?? 0,
//                   isUrgent: item.isExpress,
//                   hasErrors: item.hasErrors,
//                 }}
//                 onPress={() =>
//                   navigation.navigate('OrderDetails', {
//                     packingOrderId: item.id,
//                   })
//                 }
//               />
//             )}
//             ListEmptyComponent={
//               <View style={{ alignItems: 'center', marginTop: 40 }}>
//                 <Text>No orders assigned</Text>
//               </View>
//             }
//           />
//         )}
//       </View>
//     </View>
//   );
// };

// export default DashboardScreen;

// /* ================= STYLES ================= */

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: COLORS.background,
//   },
//   headerGradient: {
//     paddingTop:
//       Platform.OS === 'android' ? StatusBar.currentHeight + 10 : 20,
//     paddingBottom: 25,
//     paddingHorizontal: SIZES.padding,
//     borderBottomLeftRadius: 30,
//     borderBottomRightRadius: 30,
//   },
//   headerContent: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     marginBottom: 20,
//   },
//   userRow: {
//     flexDirection: 'row',
//     alignItems: 'center',
//   },
//   avatar: {
//     width: 44,
//     height: 44,
//     borderRadius: 14,
//     backgroundColor: 'rgba(255,255,255,0.25)',
//     alignItems: 'center',
//     justifyContent: 'center',
//     marginRight: 12,
//   },
//   avatarText: {
//     color: '#fff',
//     fontSize: 18,
//     fontWeight: 'bold',
//   },
//   welcomeText: {
//     color: '#e2e8f0',
//     fontSize: 12,
//   },
//   userName: {
//     color: '#fff',
//     fontSize: 18,
//     fontWeight: 'bold',
//   },
//   rolePill: {
//     backgroundColor: 'rgba(16,185,129,0.2)',
//     paddingHorizontal: 10,
//     paddingVertical: 4,
//     borderRadius: 8,
//   },
//   roleText: {
//     color: '#6ee7b7',
//     fontSize: 12,
//     fontWeight: 'bold',
//   },
//   searchWrapper: {
//     flexDirection: 'row',
//     alignItems: 'center',
//   },
//   searchContainer: {
//     flex: 1,
//     flexDirection: 'row',
//     backgroundColor: '#fff',
//     borderRadius: 14,
//     paddingHorizontal: 14,
//     height: 48,
//     alignItems: 'center',
//     marginRight: 10,
//   },
//   searchInput: {
//     marginLeft: 8,
//     flex: 1,
//   },
//   scanButton: {
//     width: 48,
//     height: 48,
//     borderRadius: 14,
//     backgroundColor: COLORS.secondary,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   listContainer: {
//     flex: 1,
//     paddingHorizontal: SIZES.padding,
//   },
//   listContent: {
//     paddingBottom: 20,
//   },
// });






import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, ActivityIndicator, Alert, RefreshControl } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../constants/theme';

// BACKEND IMPORTS
import { useQuery } from '@apollo/client';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { GET_MY_ASSIGNED_ORDERS } from '../graphql/queries';

const DashboardScreen = ({ navigation, route }) => {
  const [user, setUser] = useState({ name: 'Packer' });
  
  // 1. Get User from Storage
  useEffect(() => {
    // Try to get user from params OR storage
    if (route.params?.user) {
        setUser(route.params.user);
    } else {
        AsyncStorage.getItem('user').then(u => {
            if (u) setUser(JSON.parse(u));
        });
    }
  }, [route.params]);

  // 2. FETCH ORDERS
  const { data, loading, error, refetch } = useQuery(GET_MY_ASSIGNED_ORDERS, {
    pollInterval: 5000, // Auto-refresh every 5s
    onError: (err) => console.log("Dashboard Error:", err.message)
  });

  const handleOrderPress = (order) => {
    console.log("👉 CLICKED ORDER:", order.orderNumber);
    console.log("🆔 ID BEING PASSED:", order.id); // <--- DEBUG CHECK

    if (!order.id) {
        Alert.alert("Error", "This order has no ID. Cannot open.");
        return;
    }

    navigation.navigate('OrderDetails', { 
      order: order, // Passing the FULL order object
      user: user 
    });
  };

  const renderOrderCard = ({ item }) => (
    <TouchableOpacity 
      style={styles.card} 
      onPress={() => handleOrderPress(item)}
      activeOpacity={0.7}
    >
      <View style={styles.cardHeader}>
        <Text style={styles.orderId}>#{item.orderNumber || item.orderId}</Text>
        <View style={[styles.badge, item.status === 'ASSIGNED' ? styles.badgeAssigned : styles.badgeProgress]}>
          <Text style={styles.badgeText}>{item.status}</Text>
        </View>
      </View>
      
      <Text style={styles.date}>Assigned: {new Date(item.assignedAt).toLocaleTimeString()}</Text>
      
      <View style={styles.divider} />
      
      <View style={styles.cardFooter}>
        <Text style={styles.itemsText}>{item.items?.length || 0} Items</Text>
        <Ionicons name="chevron-forward" size={20} color={COLORS.textLight} />
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient colors={[COLORS.primary, COLORS.primaryLight]} style={styles.header}>
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.welcomeText}>Welcome,</Text>
            <Text style={styles.userName}>{user.name}</Text>
          </View>
          <TouchableOpacity onPress={() => refetch()} style={styles.refreshBtn}>
            <Ionicons name="reload" size={20} color="white" />
          </TouchableOpacity>
        </View>
      </LinearGradient>

      {/* List */}
      <View style={styles.listContainer}>
        <Text style={styles.sectionTitle}>My Tasks</Text>

        {loading && !data ? (
          <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 20 }} />
        ) : (
          <FlatList
            data={data?.getMyAssignedOrders || []}
            keyExtractor={item => item.id}
            renderItem={renderOrderCard}
            refreshControl={<RefreshControl refreshing={loading} onRefresh={refetch} />}
            ListEmptyComponent={
              <Text style={styles.emptyText}>No orders assigned right now.</Text>
            }
            contentContainerStyle={{ paddingBottom: 20 }}
          />
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  header: { padding: 20, paddingTop: 60, borderBottomLeftRadius: 30, borderBottomRightRadius: 30 },
  headerContent: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  welcomeText: { color: '#e2e8f0', fontSize: 14 },
  userName: { color: 'white', fontSize: 22, fontWeight: 'bold' },
  refreshBtn: { backgroundColor: 'rgba(255,255,255,0.2)', padding: 8, borderRadius: 8 },
  listContainer: { flex: 1, padding: 20 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 15, color: COLORS.textDark },
  emptyText: { textAlign: 'center', color: '#94a3b8', marginTop: 50 },
  
  card: { backgroundColor: 'white', borderRadius: 16, padding: 16, marginBottom: 12, elevation: 2 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  orderId: { fontSize: 16, fontWeight: 'bold', color: COLORS.textDark },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  badgeAssigned: { backgroundColor: '#e0f2fe' },
  badgeProgress: { backgroundColor: '#fef3c7' },
  badgeText: { fontSize: 10, fontWeight: 'bold', color: COLORS.textDark, textTransform: 'uppercase' },
  date: { fontSize: 12, color: COLORS.textLight, marginTop: 4 },
  divider: { height: 1, backgroundColor: '#f1f5f9', marginVertical: 12 },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  itemsText: { fontSize: 14, fontWeight: '600', color: COLORS.primary },
});

export default DashboardScreen;