// import React, { useState, useEffect, useRef } from 'react';
// import { View, Text, FlatList, TouchableOpacity, StyleSheet, Alert, Modal, Vibration, StatusBar, Platform, LayoutAnimation, UIManager, Animated, Easing } from 'react-native';
// import { CameraView, useCameraPermissions } from 'expo-camera';
// import { LinearGradient } from 'expo-linear-gradient';
// import { Ionicons } from '@expo/vector-icons';
// import * as Speech from 'expo-speech';
// import { COLORS, SIZES } from '../constants/theme';
// import { MOCK_ORDERS } from '../constants/mockData';
// import PackingListItem from '../components/PackingListItem';

// if (Platform.OS === 'android') {
//   if (UIManager.setLayoutAnimationEnabledExperimental) {
//     UIManager.setLayoutAnimationEnabledExperimental(true);
//   }
// }

// const OrderDetailsScreen = ({ navigation, route }) => {
//   const { orderId, user } = route.params;
//   const [items, setItems] = useState([]);
//   const [isScannerVisible, setScannerVisible] = useState(false);
//   const [scanned, setScanned] = useState(false);
//   const [permission, requestPermission] = useCameraPermissions();
//   const laserValue = useRef(new Animated.Value(0)).current;

//   // Initialize Items
//   useEffect(() => {
//     const order = MOCK_ORDERS.find(o => o.id === orderId);
//     if (order && order.items) {
//         const initializedItems = order.items.map(item => ({
//             ...item,
//             scannedCount: 0 
//         }));
//         setItems(JSON.parse(JSON.stringify(initializedItems)));
//     }
//   }, [orderId]);

//   // Laser Animation
//   useEffect(() => {
//     if (isScannerVisible) {
//       Animated.loop(
//         Animated.sequence([
//           Animated.timing(laserValue, { toValue: 280, duration: 1500, easing: Easing.linear, useNativeDriver: true }),
//           Animated.timing(laserValue, { toValue: 0, duration: 1500, easing: Easing.linear, useNativeDriver: true })
//         ])
//       ).start();
//     } else {
//       laserValue.setValue(0);
//     }
//   }, [isScannerVisible]);

//   const openScanner = async () => {
//     if (!permission?.granted) {
//       const { granted } = await requestPermission();
//       if (!granted) return Alert.alert("Error", "Permission needed.");
//     }
//     setScanned(false);
//     setScannerVisible(true);
//   };

//   const handleBarCodeScanned = ({ data }) => {
//     if (scanned) return;
    
//     // Find item with matching EAN
//     const targetItemIndex = items.findIndex(item => item.ean === data);

//     if (targetItemIndex !== -1) {
//       const item = items[targetItemIndex];

//       // Check if ALREADY FULL
//       if (item.scannedCount >= item.qty) {
//          setScanned(true);
//          Vibration.vibrate([0, 50, 50, 50]); 
//          Speech.speak("Item already full.", { rate: 1.1 });
//          Alert.alert("⚠️ Full", `You have already scanned ${item.qty} of ${item.name}.`, [{ text: "OK", onPress: () => setScannerVisible(false) }]);
//          return;
//       }

//       // --- VALID SCAN (Increment Count) ---
//       setScanned(true);
//       Vibration.vibrate(); 
      
//       // Update State
//       const newItems = [...items];
//       newItems[targetItemIndex].scannedCount += 1;
      
//       const newCount = newItems[targetItemIndex].scannedCount;
//       const totalQty = newItems[targetItemIndex].qty;
//       const remaining = totalQty - newCount;

//       // Voice Logic
//       if (newCount === totalQty) {
//           Speech.speak(`Item Complete.`, { rate: 1.1 });
//           LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
//           // Move completed item to bottom
//           const completedItem = newItems.splice(targetItemIndex, 1)[0];
//           newItems.push(completedItem);
//       } else {
//           Speech.speak(`Verified.`, { rate: 1.2 });
//       }

//       setItems(newItems);

//       // --- CRITICAL CHANGE: CLOSE SCANNER IMMEDIATELY ---
//       // This prevents double scanning the same item
//       setScannerVisible(false); 

//     } else {
//       // --- WRONG ITEM ---
//       setScanned(true);
//       Vibration.vibrate([0, 100, 50, 100]); 
//       Speech.speak("Error. Wrong Item.", { rate: 1.2 });
//       Alert.alert("❌ WRONG ITEM", `Barcode ${data} is not in this order.`, [
//         { text: "Try Again", onPress: () => setScanned(false) }
//       ]);
//     }
//   };

//   const totalUnitsRequired = items.reduce((acc, item) => acc + item.qty, 0);
//   const totalUnitsScanned = items.reduce((acc, item) => acc + item.scannedCount, 0);
//   const isComplete = totalUnitsRequired > 0 && totalUnitsScanned === totalUnitsRequired;
//   const progressPercent = totalUnitsRequired > 0 ? (totalUnitsScanned / totalUnitsRequired) * 100 : 0;

//   const handleComplete = () => {
//     if (!isComplete) return Alert.alert("Incomplete", "Please scan ALL units first.");
//     navigation.navigate('CameraVerification', { orderId, user });
//   };

//   return (
//     <View style={styles.container}>
//       <StatusBar barStyle="light-content" backgroundColor={COLORS.primary} />
      
//       <LinearGradient colors={[COLORS.primary, COLORS.primaryLight]} style={styles.header}>
//         <View style={styles.headerRow}>
//           <View>
//              <Text style={styles.headerLabel}>ORDER ID</Text>
//              <Text style={styles.headerTitle}>{orderId}</Text>
//           </View>
//           <View style={styles.progressBadge}>
//              <Text style={styles.progressText}>{Math.round(progressPercent)}% Done</Text>
//           </View>
//         </View>

//         <View style={styles.progressBarContainer}>
//            <View style={[styles.progressBarFill, { width: `${progressPercent}%` }]} />
//         </View>
//         <Text style={styles.progressSubtext}>{totalUnitsScanned} of {totalUnitsRequired} units scanned</Text>
//       </LinearGradient>

//       <View style={styles.listContainer}>
//         <FlatList 
//           data={items}
//           keyExtractor={item => item.id}
//           renderItem={({ item }) => <PackingListItem item={item} />}
//           contentContainerStyle={{ paddingBottom: 100 }}
//           showsVerticalScrollIndicator={false}
//         />
//       </View>

//       <View style={styles.footer}>
//         {!isComplete ? (
//           <TouchableOpacity style={styles.fabButton} onPress={openScanner} activeOpacity={0.8}>
//              <LinearGradient colors={['#1e293b', '#0f172a']} style={styles.fabGradient}>
//                 <Ionicons name="qr-code-outline" size={24} color="#fff" />
//                 <Text style={styles.fabText}>SCAN NEXT ITEM</Text>
//              </LinearGradient>
//           </TouchableOpacity>
//         ) : (
//           <TouchableOpacity style={styles.fabButton} onPress={handleComplete} activeOpacity={0.8}>
//              <LinearGradient colors={[COLORS.secondary, '#059669']} style={styles.fabGradient}>
//                 <Ionicons name="camera" size={24} color="#fff" />
//                 <Text style={styles.fabText}>VERIFY BOX</Text>
//              </LinearGradient>
//           </TouchableOpacity>
//         )}
//       </View>

//       <Modal visible={isScannerVisible} animationType="slide" onRequestClose={() => setScannerVisible(false)}>
//         <View style={styles.modalContainer}>
//           <CameraView style={styles.camera} onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}>
            
//             <View style={styles.overlayHeader}>
//                 <Text style={styles.overlayTitle}>SCAN SINGLE UNIT</Text>
//                 <TouchableOpacity onPress={() => setScannerVisible(false)} style={styles.closeBtn}>
//                    <Ionicons name="close" size={24} color="#fff" />
//                 </TouchableOpacity>
//             </View>

//             <View style={styles.scannerFrame}>
//                <Animated.View style={[styles.laserLine, { transform: [{ translateY: laserValue }] }]} />
//                <Text style={styles.scannerHint}>Align barcode inside frame</Text>
//             </View>
            
//           </CameraView>
//         </View>
//       </Modal>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: { flex: 1, backgroundColor: COLORS.background },
//   header: {
//     paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight + 20 : 50,
//     paddingBottom: 30, paddingHorizontal: SIZES.padding,
//     borderBottomLeftRadius: 30, borderBottomRightRadius: 30,
//   },
//   headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
//   headerLabel: { color: 'rgba(255,255,255,0.6)', fontSize: 12, fontWeight: '700', letterSpacing: 1 },
//   headerTitle: { color: COLORS.white, fontSize: 24, fontWeight: '800' },
//   progressBadge: { backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
//   progressText: { color: '#fff', fontWeight: 'bold', fontSize: 12 },
//   progressBarContainer: { height: 6, backgroundColor: 'rgba(0,0,0,0.2)', borderRadius: 3, overflow: 'hidden', marginBottom: 8 },
//   progressBarFill: { height: '100%', backgroundColor: COLORS.secondary },
//   progressSubtext: { color: 'rgba(255,255,255,0.8)', fontSize: 12 },
//   listContainer: { flex: 1, paddingHorizontal: SIZES.padding, marginTop: -20 },
//   footer: { position: 'absolute', bottom: 30, left: 20, right: 20 },
//   fabButton: { borderRadius: 16, overflow: 'hidden', shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.4, shadowRadius: 12, elevation: 8 },
//   fabGradient: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingVertical: 18 },
//   fabText: { color: '#fff', fontSize: 16, fontWeight: 'bold', marginLeft: 10, letterSpacing: 1 },
//   modalContainer: { flex: 1, backgroundColor: '#000' },
//   camera: { flex: 1, justifyContent: 'center', alignItems: 'center' },
//   overlayHeader: { position: 'absolute', top: 50, left: 20, right: 20, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', zIndex: 10 },
//   overlayTitle: { color: COLORS.secondary, fontWeight: 'bold', letterSpacing: 2 },
//   closeBtn: { backgroundColor: 'rgba(255,255,255,0.2)', padding: 10, borderRadius: 20 },
//   scannerFrame: { width: 280, height: 280, borderWidth: 2, borderColor: COLORS.secondary, borderRadius: 20, position: 'relative', overflow: 'hidden', justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.1)' },
//   laserLine: { position: 'absolute', top: 0, left: 0, right: 0, height: 2, backgroundColor: 'red', shadowColor: 'red', shadowOpacity: 1, shadowRadius: 10, width: '100%' },
//   scannerHint: { color: '#fff', position: 'absolute', bottom: 10, opacity: 0.8, fontSize: 12 },
// });

// export default OrderDetailsScreen;



















import { useMutation } from '@apollo/client';
import { Ionicons } from '@expo/vector-icons';
import { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS } from '../constants/theme';
import { START_PACKING } from '../graphql/queries';

const OrderDetailsScreen = ({ route, navigation }) => {
  // 1. GET DATA FROM NAVIGATION (Passed from Dashboard)
  const { orderId, user, order: initialOrderData } = route.params;
  const [order, setOrder] = useState(initialOrderData || {});

  // 2. SETUP START PACKING MUTATION
  const [startPacking, { loading }] = useMutation(START_PACKING, {
    onCompleted: (data) => {
      console.log("Packing Started:", data);
      // Update local status to show scanner
      setOrder({ ...order, status: 'IN_PROGRESS' });
      // Navigate to Camera/Scanner Screen (We will build this next)
      navigation.navigate('CameraScreen', { orderId: order.id });
    },
    onError: (err) => {
      Alert.alert("Error", err.message);
    }
  });

  const handleStart = () => {
    startPacking({ variables: { packingOrderId: orderId } });
  };

  const renderItem = ({ item }) => (
    <View style={styles.itemCard}>
      <Image 
        source={{ uri: item.product.image || 'https://via.placeholder.com/100' }} 
        style={styles.productImage} 
      />
      <View style={styles.itemInfo}>
        <Text style={styles.productName}>{item.product.name}</Text>
        <Text style={styles.sku}>SKU: {item.product.sku}</Text>
        <View style={styles.quantityRow}>
          <Text style={styles.qtyLabel}>Need: <Text style={styles.qtyBold}>{item.quantity}</Text></Text>
          <Text style={[styles.qtyLabel, { marginLeft: 15 }]}>
            Scanned: <Text style={{color: item.scannedQuantity >= item.quantity ? COLORS.success : COLORS.warning}}>
              {item.scannedQuantity || 0}
            </Text>
          </Text>
        </View>
      </View>
      {item.scannedQuantity >= item.quantity && (
        <Ionicons name="checkmark-circle" size={24} color={COLORS.success} />
      )}
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textDark} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Order #{order.orderId || '...'}</Text>
        <View style={{ width: 40 }} /> 
      </View>

      {/* Order Info */}
      <View style={styles.infoSection}>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{order.status}</Text>
        </View>
        <Text style={styles.subText}>Assigned to: {user.name}</Text>
      </View>

      {/* Items List */}
      <FlatList
        data={order.items || []}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={<Text style={styles.sectionTitle}>Items to Pack</Text>}
      />

      {/* Bottom Action Button */}
      <View style={styles.footer}>
        {order.status === 'PENDING' ? (
          <TouchableOpacity 
            style={styles.primaryButton} 
            onPress={handleStart}
            disabled={loading}
          >
            {loading ? (
               <ActivityIndicator color="white" />
            ) : (
               <>
                 <Text style={styles.buttonText}>Start Packing</Text>
                 <Ionicons name="play" size={20} color="white" style={{marginLeft: 10}} />
               </>
            )}
          </TouchableOpacity>
        ) : (
          <TouchableOpacity 
            style={[styles.primaryButton, { backgroundColor: COLORS.secondary }]} 
            onPress={() => navigation.navigate('CameraScreen', { orderId: order.id })}
          >
            <Text style={styles.buttonText}>Continue Scanning</Text>
            <Ionicons name="scan" size={20} color="white" style={{marginLeft: 10}} />
          </TouchableOpacity>
        )}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20 },
  backButton: { padding: 8, backgroundColor: 'white', borderRadius: 12, elevation: 2 },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: COLORS.textDark },
  
  infoSection: { paddingHorizontal: 20, marginBottom: 20 },
  badge: { alignSelf: 'flex-start', backgroundColor: '#e0f2fe', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6, marginBottom: 8 },
  badgeText: { color: COLORS.primary, fontWeight: '700', fontSize: 12 },
  subText: { color: COLORS.textLight },
  
  listContent: { paddingHorizontal: 20, paddingBottom: 100 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 15, color: COLORS.textDark },
  
  itemCard: { flexDirection: 'row', backgroundColor: 'white', borderRadius: 16, padding: 12, marginBottom: 12, alignItems: 'center', elevation: 2 },
  productImage: { width: 60, height: 60, borderRadius: 8, backgroundColor: '#f1f5f9' },
  itemInfo: { flex: 1, marginLeft: 15 },
  productName: { fontSize: 16, fontWeight: '600', color: COLORS.textDark, marginBottom: 4 },
  sku: { fontSize: 12, color: COLORS.textLight, marginBottom: 6 },
  quantityRow: { flexDirection: 'row' },
  qtyLabel: { fontSize: 13, color: COLORS.textLight },
  qtyBold: { fontWeight: 'bold', color: COLORS.textDark },
  
  footer: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 20, backgroundColor: 'white', borderTopWidth: 1, borderTopColor: '#f1f5f9' },
  primaryButton: { backgroundColor: COLORS.primary, height: 56, borderRadius: 16, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', shadowColor: COLORS.primary, shadowOpacity: 0.3, shadowRadius: 10, elevation: 8 },
  buttonText: { color: 'white', fontSize: 18, fontWeight: 'bold' }
});

export default OrderDetailsScreen;