// import React, { useState, useEffect, useRef } from 'react';
// import { View, Text, StyleSheet, TouchableOpacity, Image, Alert, SafeAreaView, StatusBar } from 'react-native';
// import { CameraView, useCameraPermissions } from 'expo-camera';
// import * as MediaLibrary from 'expo-media-library';
// import ViewShot from 'react-native-view-shot';
// import { Ionicons } from '@expo/vector-icons';
// import { LinearGradient } from 'expo-linear-gradient';
// import { COLORS } from '../constants/theme';

// const PHOTO_STEPS = [
//   { id: 'inner1', label: 'STEP 1 / 3', desc: 'Capture items inside the box' },
//   { id: 'inner2', label: 'STEP 2 / 3', desc: 'Capture protective packaging' },
//   { id: 'outer', label: 'STEP 3 / 3', desc: 'Capture sealed box with label' },
// ];

// const CameraScreen = ({ navigation, route }) => {
//   const { orderId, user } = route.params;
//   const [permission, requestPermission] = useCameraPermissions();
//   const [mediaPermission, requestMediaPermission] = MediaLibrary.usePermissions();
//   const cameraRef = useRef(null);
//   const viewShotRef = useRef(null);
//   const [currentStepIndex, setCurrentStepIndex] = useState(0);
//   const [currentPhoto, setCurrentPhoto] = useState(null);
//   const [isProcessing, setIsProcessing] = useState(false);
//   const currentStep = PHOTO_STEPS[currentStepIndex];

//   useEffect(() => {
//     (async () => {
//        if (!permission?.granted) requestPermission();
//        if (!mediaPermission?.granted) requestMediaPermission();
//     })();
//   }, []);

//   const takePicture = async () => {
//     if (cameraRef.current) {
//       try {
//         const data = await cameraRef.current.takePictureAsync({ quality: 0.8, skipProcessing: true });
//         setCurrentPhoto(data.uri); 
//       } catch (error) { Alert.alert("Error", "Failed to take picture"); }
//     }
//   };

//   const confirmAndNext = async () => {
//     setIsProcessing(true);
//     try {
//       const uri = await viewShotRef.current.capture();
//       await MediaLibrary.saveToLibraryAsync(uri);

//       if (currentStepIndex < PHOTO_STEPS.length - 1) {
//         setCurrentPhoto(null);
//         setCurrentStepIndex(prev => prev + 1);
//       } else {
//         Alert.alert("🎉 Done!", "Order Verified & Saved.", [{ text: "Finish", onPress: () => navigation.popToTop() }]);
//       }
//     } catch (error) { Alert.alert("Error", "Save failed"); } 
//     finally { setIsProcessing(false); }
//   };

//   if (!permission?.granted) return <View style={{flex:1, backgroundColor:'#000'}} />;

//   // --- PREVIEW MODE ---
//   if (currentPhoto) {
//     return (
//       <View style={styles.container}>
//         <StatusBar hidden />
//         <ViewShot ref={viewShotRef} style={{ flex: 1 }} options={{ format: "jpg", quality: 0.9 }}>
//           <Image source={{ uri: currentPhoto }} style={{ flex: 1 }} />
          
//           {/* Watermark Overlay */}
//           <LinearGradient colors={['transparent', 'rgba(0,0,0,0.9)']} style={styles.watermarkGradient}>
//             <View style={styles.tagBadge}>
//                  <Text style={styles.tagText}>{currentStep.id.toUpperCase()}</Text>
//             </View>
//             <Text style={styles.wmTitle}>PACKED BY: {user.name.toUpperCase()}</Text>
//             <Text style={styles.wmSub}>ID: {user.id} • ORDER: {orderId}</Text>
//             <Text style={styles.wmTime}>{new Date().toLocaleString()}</Text>
//           </LinearGradient>
//         </ViewShot>

//         {/* Floating Actions */}
//         <View style={styles.actionOverlay}>
//             <TouchableOpacity onPress={() => setCurrentPhoto(null)} style={styles.btnBlur}>
//                 <Ionicons name="refresh" size={24} color="#fff" />
//             </TouchableOpacity>
            
//             <TouchableOpacity onPress={confirmAndNext} style={styles.btnPrimary}>
//                 <Text style={styles.btnText}>{isProcessing ? "SAVING..." : "CONFIRM & NEXT"}</Text>
//                 <Ionicons name="arrow-forward" size={20} color="#fff" style={{marginLeft:8}} />
//             </TouchableOpacity>
//         </View>
//       </View>
//     );
//   }

//   // --- CAMERA MODE ---
//   return (
//     <View style={styles.container}>
//       <StatusBar hidden />
//       <CameraView style={{ flex: 1 }} ref={cameraRef} facing="back">
        
//         {/* Top HUD */}
//         <LinearGradient colors={['rgba(0,0,0,0.8)', 'transparent']} style={styles.topHud}>
//             <Text style={styles.stepLabel}>{currentStep.label}</Text>
//             <Text style={styles.stepDesc}>{currentStep.desc}</Text>
//             <View style={styles.dotsRow}>
//                 {PHOTO_STEPS.map((_, i) => (
//                     <View key={i} style={[styles.dot, currentStepIndex === i ? styles.activeDot : null]} />
//                 ))}
//             </View>
//         </LinearGradient>

//         {/* Bottom Controls */}
//         <View style={styles.bottomControls}>
//             <TouchableOpacity onPress={() => navigation.goBack()} style={styles.iconBtn}>
//                 <Ionicons name="close" size={28} color="#fff" />
//             </TouchableOpacity>

//             <TouchableOpacity onPress={takePicture} style={styles.shutterBtn}>
//                 <View style={styles.shutterInner} />
//             </TouchableOpacity>

//             <View style={{width: 50}} /> 
//         </View>
//       </CameraView>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: { flex: 1, backgroundColor: '#000' },
  
//   // HUD Styles
//   topHud: { paddingTop: 50, paddingBottom: 30, alignItems: 'center', width: '100%' },
//   stepLabel: { color: COLORS.secondary, fontWeight: '900', fontSize: 14, letterSpacing: 2, marginBottom: 4 },
//   stepDesc: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
//   dotsRow: { flexDirection: 'row', marginTop: 15 },
//   dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.3)', marginHorizontal: 4 },
//   activeDot: { backgroundColor: COLORS.secondary, width: 20 },

//   bottomControls: { position: 'absolute', bottom: 50, flexDirection: 'row', width: '100%', justifyContent: 'space-around', alignItems: 'center' },
//   shutterBtn: { width: 80, height: 80, borderRadius: 40, borderWidth: 4, borderColor: '#fff', justifyContent: 'center', alignItems: 'center' },
//   shutterInner: { width: 60, height: 60, borderRadius: 30, backgroundColor: '#fff' },
//   iconBtn: { padding: 15, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 50 },

//   // Watermark Styles
//   watermarkGradient: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 30, paddingBottom: 100 },
//   tagBadge: { backgroundColor: COLORS.secondary, alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4, marginBottom: 8 },
//   tagText: { color: '#000', fontWeight: 'bold', fontSize: 10 },
//   wmTitle: { color: '#fff', fontSize: 18, fontWeight: '900', letterSpacing: 0.5 },
//   wmSub: { color: '#ccc', fontSize: 12, marginTop: 4 },
//   wmTime: { color: '#888', fontSize: 10, marginTop: 2 },

//   // Action Overlay
//   actionOverlay: { position: 'absolute', bottom: 40, flexDirection: 'row', width: '100%', paddingHorizontal: 30, justifyContent: 'space-between', alignItems: 'center' },
//   btnBlur: { width: 50, height: 50, borderRadius: 25, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center' },
//   btnPrimary: { flex: 1, marginLeft: 20, height: 55, backgroundColor: COLORS.primary, borderRadius: 28, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
//   btnText: { color: '#fff', fontWeight: 'bold', fontSize: 14, letterSpacing: 1 },
// });

// export default CameraScreen;





import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, Alert, SafeAreaView, StatusBar } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as MediaLibrary from 'expo-media-library';
import ViewShot from 'react-native-view-shot';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { COLORS } from '../constants/theme';

const PHOTO_STEPS = [
  { id: 'inner1', label: 'STEP 1 / 3', desc: 'Capture items inside the box' },
  { id: 'inner2', label: 'STEP 2 / 3', desc: 'Capture protective packaging' },
  { id: 'outer', label: 'STEP 3 / 3', desc: 'Capture sealed box with label' },
];

const CameraScreen = ({ navigation, route }) => {
  const { orderId, user } = route.params;
  const [permission, requestPermission] = useCameraPermissions();
  const [mediaPermission, requestMediaPermission] = MediaLibrary.usePermissions();
  const cameraRef = useRef(null);
  const viewShotRef = useRef(null);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [currentPhoto, setCurrentPhoto] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const currentStep = PHOTO_STEPS[currentStepIndex];

  useEffect(() => {
    (async () => {
       if (!permission?.granted) requestPermission();
       if (!mediaPermission?.granted) requestMediaPermission();
    })();
  }, []);

  const takePicture = async () => {
    if (cameraRef.current) {
      try {
        const data = await cameraRef.current.takePictureAsync({ quality: 0.8, skipProcessing: true });
        setCurrentPhoto(data.uri); 
      } catch (error) { Alert.alert("Error", "Failed to take picture"); }
    }
  };

  const confirmAndNext = async () => {
    setIsProcessing(true);
    try {
      const uri = await viewShotRef.current.capture();
      await MediaLibrary.saveToLibraryAsync(uri);

      if (currentStepIndex < PHOTO_STEPS.length - 1) {
        setCurrentPhoto(null);
        setCurrentStepIndex(prev => prev + 1);
      } else {
        // --- FINAL STEP COMPLETED ---
        Alert.alert("🎉 Success!", "Order Packed & Verified Successfully.", [
            { 
                text: "Back to Dashboard", 
                onPress: () => {
                    // Navigate back with the Completed Order ID
                    navigation.navigate('Dashboard', { completedOrderId: orderId });
                }
            }
        ]);
      }
    } catch (error) { Alert.alert("Error", "Save failed"); } 
    finally { setIsProcessing(false); }
  };

  if (!permission?.granted) return <View style={{flex:1, backgroundColor:'#000'}} />;

  // --- PREVIEW MODE ---
  if (currentPhoto) {
    return (
      <View style={styles.container}>
        <StatusBar hidden />
        <ViewShot ref={viewShotRef} style={{ flex: 1 }} options={{ format: "jpg", quality: 0.9 }}>
          <Image source={{ uri: currentPhoto }} style={{ flex: 1 }} />
          
          {/* Watermark Overlay */}
          <LinearGradient colors={['transparent', 'rgba(0,0,0,0.9)']} style={styles.watermarkGradient}>
            <View style={styles.tagBadge}>
                 <Text style={styles.tagText}>{currentStep.id.toUpperCase()}</Text>
            </View>
            <Text style={styles.wmTitle}>PACKED BY: {user.name.toUpperCase()}</Text>
            <Text style={styles.wmSub}>ID: {user.id} • ORDER: {orderId}</Text>
            <Text style={styles.wmTime}>{new Date().toLocaleString()}</Text>
          </LinearGradient>
        </ViewShot>

        <View style={styles.actionOverlay}>
            <TouchableOpacity onPress={() => setCurrentPhoto(null)} style={styles.btnBlur}>
                <Ionicons name="refresh" size={24} color="#fff" />
            </TouchableOpacity>
            
            <TouchableOpacity onPress={confirmAndNext} style={styles.btnPrimary}>
                <Text style={styles.btnText}>{isProcessing ? "SAVING..." : "CONFIRM & NEXT"}</Text>
                <Ionicons name="arrow-forward" size={20} color="#fff" style={{marginLeft:8}} />
            </TouchableOpacity>
        </View>
      </View>
    );
  }

  // --- CAMERA MODE ---
  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <CameraView style={{ flex: 1 }} ref={cameraRef} facing="back">
        
        <LinearGradient colors={['rgba(0,0,0,0.8)', 'transparent']} style={styles.topHud}>
            <Text style={styles.stepLabel}>{currentStep.label}</Text>
            <Text style={styles.stepDesc}>{currentStep.desc}</Text>
            <View style={styles.dotsRow}>
                {PHOTO_STEPS.map((_, i) => (
                    <View key={i} style={[styles.dot, currentStepIndex === i ? styles.activeDot : null]} />
                ))}
            </View>
        </LinearGradient>

        <View style={styles.bottomControls}>
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.iconBtn}>
                <Ionicons name="close" size={28} color="#fff" />
            </TouchableOpacity>

            <TouchableOpacity onPress={takePicture} style={styles.shutterBtn}>
                <View style={styles.shutterInner} />
            </TouchableOpacity>

            <View style={{width: 50}} /> 
        </View>
      </CameraView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  topHud: { paddingTop: 50, paddingBottom: 30, alignItems: 'center', width: '100%' },
  stepLabel: { color: COLORS.secondary, fontWeight: '900', fontSize: 14, letterSpacing: 2, marginBottom: 4 },
  stepDesc: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  dotsRow: { flexDirection: 'row', marginTop: 15 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.3)', marginHorizontal: 4 },
  activeDot: { backgroundColor: COLORS.secondary, width: 20 },
  bottomControls: { position: 'absolute', bottom: 50, flexDirection: 'row', width: '100%', justifyContent: 'space-around', alignItems: 'center' },
  shutterBtn: { width: 80, height: 80, borderRadius: 40, borderWidth: 4, borderColor: '#fff', justifyContent: 'center', alignItems: 'center' },
  shutterInner: { width: 60, height: 60, borderRadius: 30, backgroundColor: '#fff' },
  iconBtn: { padding: 15, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 50 },
  watermarkGradient: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 30, paddingBottom: 100 },
  tagBadge: { backgroundColor: COLORS.secondary, alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4, marginBottom: 8 },
  tagText: { color: '#000', fontWeight: 'bolxsd', fontSize: 10 },
  wmTitle: { color: '#fff', fontSize: 18, fontWeight: '900', letterSpacing: 0.5 },
  wmSub: { color: '#ccc', fontSize: 12, marginTop: 4 },
  wmTime: { color: '#888', fontSize: 10, marginTop: 2 },
  actionOverlay: { position: 'absolute', bottom: 40, flexDirection: 'row', width: '100%', paddingHorizontal: 30, justifyContent: 'space-between', alignItems: 'center' },
  btnBlur: { width: 50, height: 50, borderRadius: 25, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center' },
  btnPrimary: { flex: 1, marginLeft: 20, height: 55, backgroundColor: COLORS.primary, borderRadius: 28, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  btnText: { color: '#fff', fontWeight: 'bold', fontSize: 14, letterSpacing: 1 },
});

export default CameraScreen;