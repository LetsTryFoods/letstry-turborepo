import { gql } from '@apollo/client';

export const PACKER_LOGIN = gql`
  mutation PackerLogin($input: PackerLoginInput!) {
    packerLogin(input: $input) {
      accessToken  # <--- CORRECTED: Server returns 'accessToken'
      packer {
        id
        name
        # We fetch minimal details to avoid schema conflicts
      }
    }
  }
`;

export const GET_PACKING_ORDERS = gql`
  query GetPackingOrders($packerId: String, $status: String) {
    getAllPackingOrders(packerId: $packerId, status: $status) {
      id
      orderId  
      status
      items {
        id
        quantity
        scannedQuantity 
        product {
          id
          name
          sku
          ean
          image 
        }
      }
    }
  }
`;

export const START_PACKING = gql`
  mutation StartPacking($packingOrderId: String!) {
    startPacking(packingOrderId: $packingOrderId) {
      id
      status
    }
  }
`;

export const SCAN_ITEM = gql`
  mutation ScanItem($input: ScanItemInput!) {
    scanItem(input: $input) {
      success
      message
      packingOrder {
        id
        status
        items {
          id
          scannedQuantity
        }
      }
    }
  }
`;

export const UPLOAD_EVIDENCE = gql`
  mutation UploadEvidence($input: UploadEvidenceInput!) {
    uploadEvidence(input: $input) {
      id
    }
  }
`;

export const COMPLETE_PACKING = gql`
  mutation CompletePacking($packingOrderId: String!) {
    completePacking(packingOrderId: $packingOrderId) {
      id
      status
    }
  }
`;