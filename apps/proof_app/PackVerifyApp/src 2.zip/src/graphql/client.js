import { ApolloClient, InMemoryCache, createHttpLink } from '@apollo/client';
import { setContext } from '@apollo/client/link/context';
import AsyncStorage from '@react-native-async-storage/async-storage';

// ⚠️ IMPORTANT: Replace this with your actual backend URL.
// If using Android Emulator: 'http://10.0.2.2:4000/graphql'
// If using Physical Device: Use your computer's local IP, e.g., 'http://192.168.1.5:4000/graphql'
//const API_URL = 'https://admin-api.krsna.site/graphql';
const API_URL = 'http://localhost:5001/graphql'; // Example for physical device

const httpLink = createHttpLink({
  uri: API_URL,
});

const authLink = setContext(async (_, { headers }) => {
  // Get the authentication token from storage if it exists
  const token = await AsyncStorage.getItem('userToken');
  
  // Return the headers to the context so httpLink can read them
  return {
    headers: {
      ...headers,
      authorization: token ? `Bearer ${token}` : "",
    }
  };
});

const client = new ApolloClient({
  link: authLink.concat(httpLink),
  cache: new InMemoryCache(),
});

export default client;